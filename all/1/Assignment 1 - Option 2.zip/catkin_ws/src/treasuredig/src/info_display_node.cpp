#include <ros/ros.h>
#include <turtlesim/Pose.h>
#include <treasuredig/Treasure.h> 

// Callback function for /turtle1/pose
void poseCallback(const turtlesim::Pose::ConstPtr& msg)
{
    ROS_INFO("Turtle Pose: x = %f, y = %f, theta = %f", msg->x, msg->y, msg->theta);
}

// Callback function for /turtle1/treasure
void treasureCallback(const treasuredig::Treasure::ConstPtr& msg)
{
    // Use %u for unsigned int
    ROS_INFO("Treasure Info: x = %u, y = %u, value = %u",
             msg->x, msg->y, msg->value);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "info_display_node");
    ros::NodeHandle nh;

    // Subscribe to /turtle1/pose topic
    ros::Subscriber pose_sub = nh.subscribe("/turtle1/pose", 10, poseCallback);

    // Subscribe to /turtle1/treasure topic
    ros::Subscriber treasure_sub = nh.subscribe("/turtle1/treasure", 10, treasureCallback);

    ros::spin(); // Keep the node running
    return 0;
}
