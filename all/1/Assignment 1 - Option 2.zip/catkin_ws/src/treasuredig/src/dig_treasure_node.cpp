#include <ros/ros.h>
#include <turtlesim/Pose.h>
#include <treasuredig/Treasure.h>
#include <geometry_msgs/Twist.h>
#include <cmath>

// Global variables to store the turtle and treasure data
turtlesim::Pose turtle_pose;
treasuredig::Treasure treasure_info;

// Callback function for /turtle1/pose
void poseCallback(const turtlesim::Pose::ConstPtr& msg)
{
    turtle_pose = *msg;
}

// Callback function for /turtle1/treasure
void treasureCallback(const treasuredig::Treasure::ConstPtr& msg)
{
    treasure_info = *msg;
}

// Function to move the turtle towards the treasure
void moveToTreasure(ros::Publisher& cmd_pub)
{
    geometry_msgs::Twist cmd_vel;

    // Calculate the distance to the treasure
    double dx = treasure_info.x - turtle_pose.x;
    double dy = treasure_info.y - turtle_pose.y;
    double distance = std::sqrt(dx * dx + dy * dy);

    // Check if the turtle is close enough to the treasure
    if (distance < 0.1) // Adjust this threshold as needed
    {
        cmd_vel.linear.x = 0.0;
        cmd_vel.angular.z = 0.0;
    }
    else
    {
        // Calculate the angle to the treasure
        double target_angle = std::atan2(dy, dx);
        double angle_diff = target_angle - turtle_pose.theta;

        // Normalize angle_diff to the range [-pi, pi]
        while (angle_diff > M_PI) angle_diff -= 2 * M_PI;
        while (angle_diff < -M_PI) angle_diff += 2 * M_PI;

        // Set the linear and angular velocities
        cmd_vel.linear.x = std::min(distance, 1.0); // Adjust speed as needed
        cmd_vel.angular.z = 2 * angle_diff; // Adjust turning speed as needed
    }

    cmd_pub.publish(cmd_vel);
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "dig_treasure_node");
    ros::NodeHandle nh;

    // Subscribe to the /turtle1/pose topic
    ros::Subscriber pose_sub = nh.subscribe("/turtle1/pose", 10, poseCallback);

    // Subscribe to the /turtle1/treasure topic
    ros::Subscriber treasure_sub = nh.subscribe("/turtle1/treasure", 10, treasureCallback);

    // Publisher for turtle movement commands
    ros::Publisher cmd_pub = nh.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);

    ros::Rate rate(10); // 10 Hz

    while (ros::ok())
    {
        moveToTreasure(cmd_pub);
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
