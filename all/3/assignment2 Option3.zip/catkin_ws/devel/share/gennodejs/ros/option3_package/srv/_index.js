
"use strict";

let CustomService = require('./CustomService.js')

module.exports = {
  CustomService: CustomService,
};
