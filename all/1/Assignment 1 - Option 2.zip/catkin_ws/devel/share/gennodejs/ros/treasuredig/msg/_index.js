
"use strict";

let Pose = require('./Pose.js');
let Treasure = require('./Treasure.js');
let Color = require('./Color.js');

module.exports = {
  Pose: Pose,
  Treasure: Treasure,
  Color: Color,
};
