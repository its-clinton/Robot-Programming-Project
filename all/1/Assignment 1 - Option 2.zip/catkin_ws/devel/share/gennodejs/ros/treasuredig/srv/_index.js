
"use strict";

let Spawn = require('./Spawn.js')
let Kill = require('./Kill.js')
let TeleportAbsolute = require('./TeleportAbsolute.js')
let SetPen = require('./SetPen.js')
let TeleportRelative = require('./TeleportRelative.js')

module.exports = {
  Spawn: Spawn,
  Kill: Kill,
  TeleportAbsolute: TeleportAbsolute,
  SetPen: SetPen,
  TeleportRelative: TeleportRelative,
};
